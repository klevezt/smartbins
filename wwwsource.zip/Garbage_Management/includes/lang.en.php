<?php
	
	// Access: The php files 
	// Purpose: Change the language

$lang['en']["Καλώς Ορίσατε στο Σύστημα Διαχείρισης Κάδων"]="Welcome to Garbage Management System";
?>